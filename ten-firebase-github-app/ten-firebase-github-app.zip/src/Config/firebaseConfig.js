export default {
  apiKey: "AIzaSyCIhXsDrTuClOvBE7K3722A4Ef2RQI6i1U",
  authDomain: "react-firebase-test-e1451.firebaseapp.com",
  projectId: "react-firebase-test-e1451",
  storageBucket: "react-firebase-test-e1451.appspot.com",
  messagingSenderId: "656073960679",
  appId: "1:656073960679:web:13e44d91d546f77170c642",
  measurementId: "G-7XQN1EFCNS"
};