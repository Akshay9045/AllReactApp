import React from 'react';

const PageNotFound = () => {
    return(
        <div>
            <h1>PageNotFound Page</h1>
        </div>
    )
}

export default PageNotFound;